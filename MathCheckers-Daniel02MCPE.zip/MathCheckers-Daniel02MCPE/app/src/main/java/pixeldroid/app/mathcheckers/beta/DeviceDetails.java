package pixeldroid.app.mathcheckers.beta;

import android.app.*;
import android.view.*;
import pixeldroid.app.mathcheckers.*;
import android.widget.*;
import android.widget.LinearLayout.*;
import android.os.*;

public class DeviceDetails
{
	public static PopupWindow popupWindow;
	public static void show(final Activity activity)
	{
		ImageView tinu29 = (ImageView)activity.findViewById(R.id.tinu29);
		LayoutInflater layoutInflater 
			= (LayoutInflater)activity.getBaseContext()
			.getSystemService(activity.LAYOUT_INFLATER_SERVICE);  
		View popupView = layoutInflater.inflate(R.layout.beta_popup, null);  
		TextView popupTitle = (TextView)popupView.findViewById(R.id.popupTitle);
		TextView popupDesc = (TextView)popupView.findViewById(R.id.popupDesc);
		popupTitle.setText("Device: " + Build.MANUFACTURER + " Model: " + Build.MODEL);
		popupDesc.setText("Version: " + getDeviceVersion());
		popupWindow = new PopupWindow(
			popupView, 
			LayoutParams.WRAP_CONTENT,  
			LayoutParams.WRAP_CONTENT);  
		popupWindow.showAtLocation(tinu29, Gravity.CENTER | Gravity.BOTTOM, 0, 0);
	}

	private static String getDeviceVersion()
	{
		int base = new Integer(Build.VERSION.SDK_INT);

		if (base <= 15 && base >= 14)
		{
			return "Ice Cream Sandwich";
		}
		else if (base <= 18 && base >= 16)
		{
			return "Jelly Bean";
		}
		else if (base <= 20 && base >= 19)
		{
			return "KitKat";
		}
		else if (base <= 22 && base >= 21)
		{
			return "Lollipop";
		}
		else if (base == 23)
		{
			return "Marshmallow";
		}
		else if (base <= 25 && base >= 24)
		{
			return "Nougat";
		}
		return "Missing?";
	}

	public static void hide()
	{
		if (popupWindow != null)
		{
			popupWindow.dismiss();
			popupWindow = null;
		}
	}
}
