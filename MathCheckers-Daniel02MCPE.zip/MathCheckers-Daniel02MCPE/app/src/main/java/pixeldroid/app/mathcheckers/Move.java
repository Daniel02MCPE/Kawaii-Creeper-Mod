package pixeldroid.app.mathcheckers;

public class Move
{
	//Row 1
	public static Boolean c70;
	public static Boolean c72;
	public static Boolean c74;
	public static Boolean c76;
	public static int t70;
	public static int t72;
	public static int t74;
	public static int t76;
	//Row 2
	public static Boolean c61;
	public static Boolean c63;
	public static Boolean c65;
	public static Boolean c67;
	public static int t61;
	public static int t63;
	public static int t65;
	public static int t67;
	//Row 3
	public static Boolean c50;
	public static Boolean c52;
	public static Boolean c54;
	public static Boolean c56;
	public static int t50;
	public static int t52;
	public static int t54;
	public static int t56;
	//Row 4
	public static Boolean c41;
	public static Boolean c43;
	public static Boolean c45;
	public static Boolean c47;
	public static int t41;
	public static int t43;
	public static int t45;
	public static int t47;
	//Row 5
	public static Boolean c30;
	public static Boolean c32;
	public static Boolean c34;
	public static Boolean c36;
	public static int t30;
	public static int t32;
	public static int t34;
	public static int t36;
	//Row 6
	public static Boolean c21;
	public static Boolean c23;
	public static Boolean c25;
	public static Boolean c27;
	public static int t21;
	public static int t23;
	public static int t25;
	public static int t27;
	//Row 7
	public static Boolean c10;
	public static Boolean c12;
	public static Boolean c14;
	public static Boolean c16;
	public static int t10;
	public static int t12;
	public static int t14;
	public static int t16;
	//Row 8
	public static Boolean c01;
	public static Boolean c03;
	public static Boolean c05;
	public static Boolean c07;
	public static int t01;
	public static int t03;
	public static int t05;
	public static int t07;

	public static void setLocations()
	{
		//Red Chips
		c70 = true; t70 = 2;
		c72 = true; t72 = 2;
		c74 = true; t74 = 2;
		c76 = true; t76 = 2;
		c61 = true; t61 = 2;
		c63 = true; t63 = 2;
		c65 = true; t65 = 2;
		c67 = true; t67 = 2;
		c50 = true; t50 = 2;
		c52 = true; t52 = 2;
		c54 = true; t54 = 2;
		c56 = true; t56 = 2;

		//Space Chips
		c41 = false; t41 = 0;
		c43 = false; t43 = 0;
		c45 = false; t45 = 0;
		c47 = false; t47 = 0;
		c30 = false; t30 = 0;
		c32 = false; t32 = 0;
		c34 = false; t34 = 0;
		c36 = false; t36 = 0;

		//Green Chips
		c21 = true; t21 = 1;
		c23 = true; t23 = 1;
		c25 = true; t25 = 1;
		c27 = true; t27 = 1;
		c10 = true; t10 = 1;
		c12 = true; t12 = 1;
		c14 = true; t14 = 1;
		c16 = true; t16 = 1;
		c01 = true; t01 = 1;
		c03 = true; t03 = 1;
		c05 = true; t05 = 1;
		c07 = true; t07 = 1;
	}

	public static void moveGreen(int location, int nxtlocation)
	{
		String integer;
		if (location == 5)
		{
			integer = Chips.unit5.getText().toString();
			if (nxtlocation == 1 && !c70)
			{
				Chips.unit1.setBackgroundResource(R.drawable.green_chip);
				Chips.unit1.setText(integer);
				c70 = true;
				t70 = 1;
				Chips.unit5.setBackgroundResource(R.drawable.blank);
				Chips.unit5.setText("");
				c61 = false;
				t61 = 0;
			}
			else if (nxtlocation == 2 && !c72)
			{
				Chips.unit2.setBackgroundResource(R.drawable.green_chip);
				Chips.unit2.setText(integer);
				c72 = true;
				t72 = 1;
				Chips.unit5.setBackgroundResource(R.drawable.blank);
				Chips.unit5.setText("");
				c61 = false;
				t61 = 0;
			}
			else
			{
				Chips.unit5.setBackgroundResource(R.drawable.green_chip);
			}
			//MainActivity.provideBtn();
		}
		else if (location == 6)
		{
			integer = Chips.unit6.getText().toString();
			if (nxtlocation == 2 && !c72)
			{
				Chips.unit2.setBackgroundResource(R.drawable.green_chip);
				Chips.unit2.setText(integer);
				c72 = true;
				t72 = 1;
				Chips.unit6.setBackgroundResource(R.drawable.blank);
				Chips.unit6.setText("");
				c63 = false;
				t63 = 0;
			}
			else if (nxtlocation == 3 && !c74)
			{
				Chips.unit3.setBackgroundResource(R.drawable.green_chip);
				Chips.unit3.setText(integer);
				c74 = true;
				t74= 1;
				Chips.unit6.setBackgroundResource(R.drawable.blank);
				Chips.unit6.setText("");
				c65 = false;
				t65 = 0;
			}
			else
			{
				Chips.unit6.setBackgroundResource(R.drawable.green_chip);
			}
			//MainActivity.provideBtn();
		}
		else if (location == 21)
		{
			integer = Chips.unit21.getText().toString();
			if (nxtlocation == 17 && !c30)
			{
				Chips.unit17.setBackgroundResource(R.drawable.green_chip);
				Chips.unit17.setText(integer);
				c30 = true;
				t30 = 1;
				Chips.unit21.setBackgroundResource(R.drawable.blank);
				Chips.unit21.setText("");
				c21 = false;
				t21 = 0;
			}
			else if (nxtlocation == 18 && !c32)
			{
				Chips.unit18.setBackgroundResource(R.drawable.green_chip);
				Chips.unit18.setText(integer);
				c32 = true;
				t32 = 1;
				Chips.unit21.setBackgroundResource(R.drawable.blank);
				Chips.unit21.setText("");
				c21 = false;
				t21 = 0;
			}
			else
			{
				Chips.unit21.setBackgroundResource(R.drawable.green_chip);
			}
			//MainActivity.provideBtn();
		}
	}
}
