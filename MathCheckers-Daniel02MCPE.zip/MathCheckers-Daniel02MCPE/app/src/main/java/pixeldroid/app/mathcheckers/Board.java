package pixeldroid.app.mathcheckers;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.widget.*;
import android.content.res.*;
import android.view.animation.*;

public class Board
{
	//Thou Shall Tinu Here
	public static ImageView tinu1;
	public static ImageView tinu2;
	public static ImageView tinu3;
	public static ImageView tinu4;
	public static ImageView tinu5;
	public static ImageView tinu6;
	public static ImageView tinu7;
	public static ImageView tinu8;
	public static ImageView tinu9;
	public static ImageView tinu10;
	public static ImageView tinu11;
	public static ImageView tinu12;
	public static ImageView tinu13;
	public static ImageView tinu14;
	public static ImageView tinu15;
	public static ImageView tinu16;
	public static ImageView tinu17;
	public static ImageView tinu18;
	public static ImageView tinu19;
	public static ImageView tinu20;
	public static ImageView tinu21;
	public static ImageView tinu22;
	public static ImageView tinu23;
	public static ImageView tinu24;
	public static ImageView tinu25;
	public static ImageView tinu26;
	public static ImageView tinu27;
	public static ImageView tinu28;
	public static ImageView tinu29;
	public static ImageView tinu30;
	public static ImageView tinu31;
	public static ImageView tinu32;
	//Thou Shall Unit Here


	public static void defineTiles(Context context, Activity activity)
	{
		int color  = Color.BLACK;
		
		tinu1 = (ImageView)activity.findViewById(R.id.tinu1);
		tinu2 = (ImageView)activity.findViewById(R.id.tinu2);
		tinu3 = (ImageView)activity.findViewById(R.id.tinu3);
		tinu4 = (ImageView)activity.findViewById(R.id.tinu4);
		tinu5 = (ImageView)activity.findViewById(R.id.tinu5);
		tinu6 = (ImageView)activity.findViewById(R.id.tinu6);
		tinu7 = (ImageView)activity.findViewById(R.id.tinu7);
		tinu8 = (ImageView)activity.findViewById(R.id.tinu8);
		tinu9 = (ImageView)activity.findViewById(R.id.tinu9);
		tinu10 = (ImageView)activity.findViewById(R.id.tinu10);
		tinu11 = (ImageView)activity.findViewById(R.id.tinu11);
		tinu12 = (ImageView)activity.findViewById(R.id.tinu12);
		tinu13 = (ImageView)activity.findViewById(R.id.tinu13);
		tinu14 = (ImageView)activity.findViewById(R.id.tinu14);
		tinu15 = (ImageView)activity.findViewById(R.id.tinu15);
		tinu16 = (ImageView)activity.findViewById(R.id.tinu16);
		tinu17 = (ImageView)activity.findViewById(R.id.tinu17);
		tinu18 = (ImageView)activity.findViewById(R.id.tinu18);
		tinu19 = (ImageView)activity.findViewById(R.id.tinu19);
		tinu20 = (ImageView)activity.findViewById(R.id.tinu20);
		tinu21 = (ImageView)activity.findViewById(R.id.tinu21);
		tinu22 = (ImageView)activity.findViewById(R.id.tinu22);
		tinu23 = (ImageView)activity.findViewById(R.id.tinu23);
		tinu24 = (ImageView)activity.findViewById(R.id.tinu24);
		tinu25 = (ImageView)activity.findViewById(R.id.tinu25);
		tinu26 = (ImageView)activity.findViewById(R.id.tinu26);
		tinu27 = (ImageView)activity.findViewById(R.id.tinu27);
		tinu28 = (ImageView)activity.findViewById(R.id.tinu28);
		tinu29 = (ImageView)activity.findViewById(R.id.tinu29);
		tinu30 = (ImageView)activity.findViewById(R.id.tinu30);
		tinu31 = (ImageView)activity.findViewById(R.id.tinu31);
		tinu32 = (ImageView)activity.findViewById(R.id.tinu32);
		
		tinu1.setBackgroundColor(color);
		tinu2.setBackgroundColor(color);
		tinu3.setBackgroundColor(color);
		tinu4.setBackgroundColor(color);
		tinu5.setBackgroundColor(color);
		tinu6.setBackgroundColor(color);
		tinu7.setBackgroundColor(color);
		tinu8.setBackgroundColor(color);
		tinu9.setBackgroundColor(color);
		tinu10.setBackgroundColor(color);
		tinu11.setBackgroundColor(color);
		tinu12.setBackgroundColor(color);
		tinu13.setBackgroundColor(color);
		tinu14.setBackgroundColor(color);
		tinu15.setBackgroundColor(color);
		tinu16.setBackgroundColor(color);
		tinu17.setBackgroundColor(color);
		tinu18.setBackgroundColor(color);
		tinu19.setBackgroundColor(color);
		tinu20.setBackgroundColor(color);
		tinu21.setBackgroundColor(color);
		tinu22.setBackgroundColor(color);
		tinu23.setBackgroundColor(color);
		tinu24.setBackgroundColor(color);
		tinu25.setBackgroundColor(color);
		tinu26.setBackgroundColor(color);
		tinu27.setBackgroundColor(color);
		tinu28.setBackgroundColor(color);
		tinu29.setBackgroundColor(color);
		tinu30.setBackgroundColor(color);
		tinu31.setBackgroundColor(color);
		tinu32.setBackgroundColor(color);
		
	}

	public static void locateChips(Context context)
	{
		
	}

	public static void showChips(Context context)
	{
		Animation fadein = AnimationUtils.loadAnimation(context, R.anim.fade_in);
		
		Chips.unit1.startAnimation(fadein);
		Chips.unit2.startAnimation(fadein);
		Chips.unit3.startAnimation(fadein);
		Chips.unit4.startAnimation(fadein);
		Chips.unit5.startAnimation(fadein);
		Chips.unit6.startAnimation(fadein);
		Chips.unit7.startAnimation(fadein);
		Chips.unit8.startAnimation(fadein);
		Chips.unit9.startAnimation(fadein);
		Chips.unit10.startAnimation(fadein);
		Chips.unit11.startAnimation(fadein);
		Chips.unit12.startAnimation(fadein);
		Chips.unit13.startAnimation(fadein);
		Chips.unit14.startAnimation(fadein);
		Chips.unit15.startAnimation(fadein);
		Chips.unit16.startAnimation(fadein);
		Chips.unit17.startAnimation(fadein);
		Chips.unit18.startAnimation(fadein);
		Chips.unit19.startAnimation(fadein);
		Chips.unit20.startAnimation(fadein);
		Chips.unit21.startAnimation(fadein);
		Chips.unit22.startAnimation(fadein);
		Chips.unit23.startAnimation(fadein);
		Chips.unit24.startAnimation(fadein);
		Chips.unit25.startAnimation(fadein);
		Chips.unit26.startAnimation(fadein);
		Chips.unit27.startAnimation(fadein);
		Chips.unit28.startAnimation(fadein);
		Chips.unit29.startAnimation(fadein);
		Chips.unit30.startAnimation(fadein);
		Chips.unit31.startAnimation(fadein);
		Chips.unit32.startAnimation(fadein);
	}

	public static void setXs(Bitmap bitmap)
	{
		
	}
}
